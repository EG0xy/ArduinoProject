#include "edu.h"
#include "Arduino.h"



edu::edu(){

  DDRB=0b11111111; 
  DDRD=0b11110000;	
	
 }
 
 
void edu::digit (int Adigit){
 
_Adigit=Adigit;
_Ldigit = _Adigit / 100;
_Rdigit = _Adigit % 100;
  
}

void edu::digits (uint8_t Ldigit, uint8_t Rdigit){
 
 _Ldigit=Ldigit;
 _Rdigit=Rdigit;

}

void edu::ledprint(){

  do1 = digit_map[_Ldigit / 10];
  do2 = digit_map[_Ldigit % 10];
  do3 = digit_map[_Rdigit / 10];
  do4 = digit_map[_Rdigit % 10];

 
  ta=micros();
  if(ta-tb>=100){
  mcount++;
  if(mcount==4) mcount=0;
    
    if(mcount==0){
    PORTD|=0b11110000; 
    PORTB=do1;
    PORTD^=0b00010000;   
    }
    
    if(mcount==1){
    PORTD|=0b11110000; 
    PORTB=do2;
    PORTD^=0b00100000; 
    }

    if(mcount==2){
    PORTD|=0b11110000; 
    PORTB=do3;
    PORTD^=0b01000000;   
    }

    if(mcount==3){
    PORTD|=0b11110000; 
    PORTB=do4;
    PORTD^=0b10000000;  
    }    
    
  tb=ta;
  }
  
}





