#ifndef edu_h
#define edu_h
#include "Arduino.h"

#define yes HIGH
#define no LOW

class edu
{

   public:
    edu();
	void digit(int); //print 4 digits at once
	void digits(uint8_t, uint8_t); // print 2 2-number-digits.
	void ledprint();
	
    uint8_t mcount=0;
	int ta=0;
	int tb=0;

	uint8_t do1=0;
	uint8_t do2=0;
	uint8_t do3=0;
	uint8_t do4=0;	
    uint8_t digit_map[11]={
    B00111111, // 0
    B00000110, // 1
    B01011011, // 2
    B01001111, // 3
    B01100110, // 4
    B01101101, // 5
    B01111101, // 6
    B00000111, // 7
    B01111111, // 8
    B01101111 }; //9
	
	private:
    int _Adigit=0;
	uint8_t _Ldigit=0;
	uint8_t _Rdigit=0;  
	
};

#endif