#include "button.h"
#include "Arduino.h"


button::button(uint8_t pin){
  _pin=pin;
  
 }
 
 void button::buttonWatchdog( ){
 
  adc=analogRead(_pin);
  
// 1013-1023(No press); 0-10; 505-517 ; 674-688; 761-773; 812-824; 846-858; 871-883; 888-901; 903-915;;  

  if(adc>=1013) Now_bReads=0;
  if(adc<=10) Now_bReads=1; 
  if(adc>=505 && adc<=517) Now_bReads=2;
  if(adc>=674 && adc<=688) Now_bReads=3;
  if(adc>=761 && adc<=773) Now_bReads=4;
  if(adc>=812 && adc<=824) Now_bReads=5;  
  if(adc>=846 && adc<=858) Now_bReads=6;
  if(adc>=871 && adc<=883) Now_bReads=7;
  if(adc>=888 && adc<=901) Now_bReads=8;
  if(adc>=903 && adc<=915) Now_bReads=9;  
  
   if(Now_bReads!=Last_bRead){
   tpast=millis();
   }
  
  tnow=millis();
  if(tnow-tpast>25 && Now_bReads!=buttonState){
      buttonState=Now_bReads; 
      if(Now_bReads>0)button_Counter=buttonState;
    }


  if(Now_bReads==0 && tnow-tpast>25 ){
    buttonRead=button_Counter;
    button_Counter=0;
    }

   if(Now_bReads && tnow-tpast>500 ){
    buttonRead=-button_Counter;
    button_Counter=0;
    
    }   
  

    Last_bRead=Now_bReads;
 
 
 }
 
 
 
 
 void button::buttonWatchbot( ){
 
	 pinMode(_pin, INPUT);
	 digitalWrite(_pin, HIGH);
 
  Now_bReads=digitalRead(_pin);
  
  
   if(Now_bReads!=Last_bRead){
   tpast=millis();
   }
  
  tnow=millis();
  if(tnow-tpast>25 && Now_bReads!=buttonState){
      buttonState=Now_bReads; 
      if(Now_bReads==0)button_Counter=1;
    }


  if(Now_bReads==1 && tnow-tpast>25 ){
    buttonRead=button_Counter;
    button_Counter=0;
    }

   if(Now_bReads==0 && tnow-tpast>500 ){
    buttonRead=-button_Counter;
    button_Counter=0;
    
    }   
  

    Last_bRead=Now_bReads;
 
 
 }