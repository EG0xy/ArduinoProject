#ifndef button_H
#define button_H

#include <Arduino.h>

#define buttonRead br

class button
{
  public:
	button(uint8_t pin);
	void buttonWatchdog();
	void buttonWatchbot();	
	uint16_t adc;
	uint8_t Now_bReads;
	uint8_t Last_bRead=0;
	uint8_t buttonState;
	uint8_t button_Counter;
	int8_t buttonRead; // 0-1-2-3-4-5...	
    uint16_t tnow, tpast;
  
  private:
	uint8_t _pin;

};

#endif

